package com.learnJDBC;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.ResultSet;

public class HospitalManagementSystem {
    // Database connection details
    private static final String url = "jdbc:mysql://localhost:3306/hospital";
    private static final String username = "root";
    private static final String password = "Surya@5624";

    public static void main(String[] args) {
        // Load MySQL JDBC driver class
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Scanner scanner = new Scanner(System.in);

        try {
            // Establish connection to database using the credentials above
            Connection connection = DriverManager.getConnection(url, username, password);

            // Create Patient and Doctor objects for handling related operations
            Patient patient = new Patient(connection, scanner);
            Doctor doctor = new Doctor(connection);

            // Main loop to keep the application running until user exits
            while (true) {
                // Display menu options to the user
                System.out.println("Hospital Management System");
                System.out.println("1.Add Patient");
                System.out.println("2.View Patients");
                System.out.println("3.View Doctors");
                System.out.println("4.Book Appointment");
                System.out.println("5.Exit");
                System.out.print("Please enter your choice: ");

                int choice = scanner.nextInt();

                // Handle user choice using switch statement
                switch (choice) {
                    case 1:
                        // Call method to add patient details
                        patient.addPatient();
                        System.out.println();
                        break;
                    case 2:
                        // Display list of patients
                        patient.viewPatients();
                        System.out.println();
                        break;
                    case 3:
                        // Display list of doctors
                        doctor.viewDoctors();
                        System.out.println();
                        break;
                    case 4:
                        // Book an appointment between patient and doctor
                        bookAppointment(patient, doctor, connection, scanner);
                        System.out.println();
                        break;
                    case 5:
                        // Exit the program gracefully
                        System.out.println("THANK YOU!! FOR USING HOSPITAL MANAGEMENT SYSTEM.");
                        return;
                    default:
                        // Handle invalid inputs
                        System.out.println("Please enter a valid Input");
                        break;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to book an appointment
     * @param patient Patient object to verify patient existence
     * @param doctor Doctor object to verify doctor existence
     * @param connection Database connection object
     * @param scanner Scanner object to read user input
     */
    public static void bookAppointment(Patient patient, Doctor doctor, Connection connection, Scanner scanner) {
        // Get patient ID from user
        System.out.println("Please Enter patient ID: ");
        int patientID = scanner.nextInt();

        // Get doctor ID from user
        System.out.println("Please Enter Doctor ID: ");
        int doctorID = scanner.nextInt();

        // Get appointment date in YYYY-MM-DD format
        System.out.println("Please Enter Appointment Date (YYYY-MM-DD): ");
        String appointmentDate = scanner.next();

        // Verify that patient and doctor both exist
        if (patient.getPatientsByID(patientID) && doctor.getDoctorsByID(doctorID)) {
            // Check if doctor is available on the given appointment date
            if (checkDoctorAvailabilty(doctorID, appointmentDate, connection)) {
                // Insert appointment into database
                String appointmentQuery = "INSERT INTO appointments (patients_id, doctor_id, appointment_date) VALUES (?, ?, ?)";

                try {
                    PreparedStatement preparedStatement = connection.prepareStatement(appointmentQuery);
                    preparedStatement.setInt(1, patientID);
                    preparedStatement.setInt(2, doctorID);
                    preparedStatement.setString(3, appointmentDate);

                    // Execute the insert operation
                    int rowsAffected = preparedStatement.executeUpdate();

                    // Confirmation message depending on success or failure
                    if (rowsAffected > 0) {
                        System.out.println("Appointment Booked Successfully.");
                    } else {
                        System.out.println("Appointment could not be booked.");
                    }

                    // Close the prepared statement to free resources
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                // Inform user if doctor is not available on requested date
                System.out.println("Doctor not available on this date!!");
            }
        } else {
            // Inform user if either patient or doctor does not exist in database
            System.out.println("Either doctor or patient doesn't exist!!");
        }
    }

    /**
     * Check if a doctor is available for a particular date (no existing appointments)
     * @param doctorID ID of the doctor
     * @param appointmentDate Date to check availability
     * @param connection Database connection object
     * @return true if doctor available (no appointments), false otherwise
     */
    public static boolean checkDoctorAvailabilty(int doctorID, String appointmentDate, Connection connection) {
        String query = "SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, doctorID);
            preparedStatement.setString(2, appointmentDate);

            ResultSet resultset = preparedStatement.executeQuery();

            if (resultset.next()) {
                int count = resultset.getInt(1);
                // If count is 0, doctor has no appointments and is available
                return count == 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // Return false if any error occurs or doctor not available
        return false;
    }
}
