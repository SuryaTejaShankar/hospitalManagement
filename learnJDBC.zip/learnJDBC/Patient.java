package com.learnJDBC;

import java.sql.*;
import java.util.Scanner;

public class Patient {
    // Instance variables to hold the database connection and scanner object for input
    private Connection connection;
    private Scanner scanner;

    // Constructor to initialize connection and scanner
    public Patient(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    // Method to add a new patient record to the database
    public void addPatient() {
        // Prompt user for patient details
        System.out.println("Enter Patient's Name: ");
        String name = scanner.next();

        System.out.println("Enter Patient's Age: ");
        int age = scanner.nextInt();

        System.out.println("Enter Patient's Gender: ");
        String gender = scanner.next();

        try {
            // SQL insert statement with placeholders (?)
            String Query = "Insert into patients(name,age,gender) values(?,?,?)";
            // Prepare the statement to prevent SQL injection and to set parameters
            PreparedStatement preparedStatement = connection.prepareStatement(Query);

            // Set the parameters in the SQL query
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, gender);

            // Execute the insert operation; returns number of affected rows
            int affectedRows = preparedStatement.executeUpdate();

            // Check if any row was inserted successfully
            if (affectedRows > 0) {
                System.out.println("Patient Added Successfully");
            } else {
                System.out.println("Failed to add Patient!!");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions by printing the stack trace
            e.printStackTrace();
        }
    }

    // Method to view all patients in the database
    public void viewPatients() {
        // SQL query to select all patient records
        String query = "select * from patients";

        try {
            // Prepare the statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            // Execute the query and get the results
            ResultSet resultset = preparedStatement.executeQuery();

            // Print table header for displaying patients
            System.out.println("Patients: ");
            System.out.println("+------------+----------------------+-----+---------+");
            System.out.println("| Patient Id | Name                 | Age | Gender  |");
            System.out.println("+------------+----------------------+-----+---------+");

            // Loop through all results and display each patient's details
            while (resultset.next()) {
                int id = resultset.getInt("id");             // Get patient id
                String name = resultset.getString("name");   // Get patient name
                int age = resultset.getInt("age");            // Get patient age
                String gender = resultset.getString("gender"); // Get patient gender

                // Format and print patient details in tabular format
                System.out.printf("| %-10d | %-20s | %-3d | %-7s |\n", id, name, age, gender);
            }

            // Print table footer
            System.out.println("+------------+----------------------+-----+---------+");

        } catch (SQLException e) {
            // Print exception details if any SQL error occurs
            e.printStackTrace();
        }
    }

    // Method to check if a patient with the given ID exists in the database
    public boolean getPatientsByID(int id) {
        // SQL query to find a patient by ID
        String query = "select * from patients where id = ?";

        try {
            // Prepare statement and set the ID parameter
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);

            // Execute the query
            ResultSet resultset = preparedStatement.executeQuery();

            // If resultset has at least one row, patient exists
            if (resultset.next()) {
                return true;
            } else {
                return false; // Patient not found
            }
        } catch (SQLException e) {
            // Handle SQL exceptions
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        // This can be used to test this class independently if needed.
    }
}
