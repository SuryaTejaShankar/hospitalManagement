package com.learnJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class JDBCInsertRecord {

    public static void main(String[] args) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        

        String URL = "jdbc:mysql://localhost:3306/JDBCMySQL";
        String Username = "root";
        String Password = "Surya@5624";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
       
        } catch (ClassNotFoundException e) {
            System.out.println("Int catch: " + e.getMessage());
            return;
        }

        try {
            con = DriverManager.getConnection(URL, Username, Password);
            stmt = con.createStatement();
            stmt.execute("INSERT INTO students VALUES (3, 'Bhanu', 'IT')");
            stmt.execute("INSERT INTO students VALUES (4, 'Sahil', 'IT')");
            stmt.execute("INSERT INTO students VALUES (5, 'Karthik', 'DS')");
            stmt.execute("INSERT INTO students VALUES (6, 'Sonu', 'CSE')");

            System.out.println("Records inserted successfully!");
            stmt.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
        } finally {
        	if (con != null) {
            try {
            	stmt.close();
                con.close();
                System.out.println("Terminated Successfully");
            } catch (Exception e) {
                System.out.println("Oops! Some serious issue");
            }
        }
    }
}
}
