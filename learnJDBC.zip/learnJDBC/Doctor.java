package com.learnJDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Doctor {
    // Instance variable to hold the database connection
    private Connection connection;

    // Constructor to initialize the database connection
    public Doctor(Connection connection) {
        this.connection = connection;
    }

    // Method to view all doctors from the database
    public void viewDoctors() {
        // SQL query to select all records from doctors table
        String query = "select * from doctors";

        try {
            // Prepare the SQL statement to prevent SQL injection
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            // Execute the query and get the results
            ResultSet resultset = preparedStatement.executeQuery();

            // Print table header for doctors list
            System.out.println("Doctors: ");
            System.out.println("+------------+----------------------+----------------------+");
            System.out.println("| Doctor Id  | Name                 | Specialization       |");
            System.out.println("+------------+----------------------+----------------------+");

            // Loop through each row in the result set
            while (resultset.next()) {
                int id = resultset.getInt("id");                // Get doctor id
                String name = resultset.getString("name");      // Get doctor name
                // Note: "specilization" column name used here — verify correct spelling in your DB
                String specialization = resultset.getString("specilization"); 

                // Format and print each doctor's data in tabular form
                System.out.printf("| %-10d | %-20s | %-20s |\n", id, name, specialization);
            }

            // Print table footer
            System.out.println("+------------+----------------------+----------------------+");

        } catch (SQLException e) {
            // Print stack trace if an SQL exception occurs
            e.printStackTrace();
        }
    }

    // Method to check if a doctor exists by their ID
    public boolean getDoctorsByID(int id) {
        // SQL query to select doctor with specific id
        String query = "select * from doctors where id = ?";

        try {
            // Prepare the statement and set the doctor ID parameter
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);

            // Execute the query
            ResultSet resultset = preparedStatement.executeQuery();

            // If a record is found, return true
            if (resultset.next()) {
                return true;
            } else {
                // No record found, return false
                return false;
            }
        } catch (SQLException e) {
            // Print exception if something goes wrong
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        // This can be used for testing this class independently
    }
}
