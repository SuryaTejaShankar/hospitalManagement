package com.learnJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCPreparedInsert {

    public static void main(String[] args) {
        Connection con = null;
        ResultSet rs = null;

        String URL = "jdbc:mysql://localhost:3306/JDBCMySQL";
        String Username = "root";
        String Password = "Surya@5624";
        String Query = "INSERT INTO students(id, name, dept) VALUES (?, ?, ?)";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver Loaded!");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e.getMessage());
            return;
        }

        try {
            con = DriverManager.getConnection(URL, Username, Password);
            PreparedStatement preparedStatement = con.prepareStatement(Query);

            // Set all required values
            preparedStatement.setInt(1, 9); // ID
            preparedStatement.setString(2, "Abhi"); // Name
            preparedStatement.setString(3, "Biotech"); // dept

            preparedStatement.execute();

            while(rs.next()) {
    			System.out.println("_____________________________");
    			int id = rs.getInt("id");
    			String name = rs.getString("name");
    			String dept = rs.getString("dept");
    			
    			System.out.println("Student Id : "+id);
    			System.out.println("Student Name : "+name);
    			System.out.println("Student Department : "+dept);
    			System.out.println("_____________________________");
    		}

        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
        } finally {
            try {
                if (con != null) con.close();
                System.out.println("Terminated Successfully");
            } catch (Exception e) {
                System.out.println("Oops! Some serious issue");
            }
        }
    }
}
